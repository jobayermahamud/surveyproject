<nav class="sidebar sidebar-offcanvas" id="sidebar">
        <ul class="nav">
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('surveyfront')); ?>">
              <i class="icon-grid menu-icon"></i>
              <span class="menu-title">Frontend</span>
            </a>
          </li>
           
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
              <i class="icon-layout menu-icon"></i>
              <span class="menu-title">Survey Question Setup</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="ui-basic">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('add_question')); ?>">Add Question</a></li>
                <li class="nav-item"> <a class="nav-link" href="<?php echo e(url('questions')); ?>">Question list</a></li>
                
              </ul>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" data-toggle="collapse" href="#form-elements" aria-expanded="false" aria-controls="form-elements">
              <i class="icon-columns menu-icon"></i>
              <span class="menu-title">Survey</span>
              <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="form-elements">
              <ul class="nav flex-column sub-menu">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(url('addsurvey')); ?>">Add survey</a></li>
                 <li class="nav-item"><a class="nav-link" href="<?php echo e(url('survey')); ?>">Survey list</a></li>
              </ul>
            </div>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(url('surveyreport')); ?>">
              <i class="icon-grid menu-icon"></i>
              <span class="menu-title">Surveywise report</span>
            </a>
          </li>
          
        </ul>
      </nav><?php /**PATH C:\Users\webpers\Desktop\survay_project\surveyproject\resources\views/layouts/sidemenu.blade.php ENDPATH**/ ?>