<?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<body>
    <div class="container-scroller">
     <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-6 grid-margin stretch-card">
              <div class="card position-relative">
                <div class="card-body">
                  <div id="detailedReports" class="carousel slide detailed-report-carousel position-static pt-2" data-ride="carousel">
                    <div class="carousel-inner">
                        <?php
                            $counter=0;
                        ?>
                        <?php $__currentLoopData = $processData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($counter<count($processData)-1): ?>
                              <?php
                                  $counter++;
                              ?>
                                <div style='margin-top:30px' class="carousel-item">
                                    <p><?php echo e($processData[$key][0]['question_name']); ?></p>
                                    <hr>
                                    <?php for($i=0;$i<count($value);$i++): ?>
                                        <?php if($value[$i]['option_type']): ?>
                                            <p><input type='radio' data-target='option_<?php echo e($value[$i]['question_id']); ?>' url_ref='<?php echo e(URL::signedRoute('ml_opt', 
                                            ['surveyId' => $value[$i]['id'],
                                             'questionId'=>$value[$i]['question_id'],
                                             'optionId'=>$value[$i]['option_id'],
                                             'optionValue'=>$value[$i]['option_title'],
                                            ])); ?>' name='option_<?php echo e($key); ?>'/>&nbsp;<?php echo e($value[$i]['option_title']); ?></p>
                                            <hr>
                                            
                                        <?php else: ?>
                                            <textarea id='textoption_<?php echo e($value[$i]['question_id']); ?>' style='width:70%'></textarea></br>
                                        <?php endif; ?>
                                        
                                    <?php endfor; ?>

                                    <?php if($processData[$key][0]['option_type']): ?>
                                        <a opt_type='ml_opt' id='option_<?php echo e($processData[$key][0]['question_id']); ?>' href='#' class='btn btn-primary btn-sm'>VOTE</a>
                                    <?php else: ?>
                                        <a opt_type='text_opt' data-target='textoption_<?php echo e($processData[$key][0]['question_id']); ?>' href='<?php echo e(URL::signedRoute('text_opt', 
                                            ['surveyId' => $processData[$key][0]['id'],
                                             'questionId'=>$processData[$key][0]['question_id'],
                                            ])); ?>' class='btn btn-primary btn-sm'>VOTE</a>
                                    <?php endif; ?>
                                    
                                </div>
                            <?php else: ?>
                                <div style='margin-top:30px' class="carousel-item active">
                                    <p><?php echo e($processData[$key][0]['question_name']); ?></p>
                                    <hr>
                                    <?php for($i=0;$i<count($value);$i++): ?>
                                        <?php if($value[$i]['option_type']): ?>
                                            <p><input type='radio' url_ref='<?php echo e(URL::signedRoute('ml_opt', 
                                            ['surveyId' => $value[$i]['id'],
                                             'questionId'=>$value[$i]['question_id'],
                                             'optionId'=>$value[$i]['option_id'],
                                             'optionValue'=>$value[$i]['option_title'],
                                            ])); ?>' data-target='option_<?php echo e($value[$i]['question_id']); ?>' name='option_<?php echo e($key); ?>'/>&nbsp;<?php echo e($value[$i]['option_title']); ?></p>
                                            <hr>
                                            
                                        <?php else: ?>
                                            <textarea id='textoption_<?php echo e($value[$i]['question_id']); ?>' style='width:70%'></textarea></br>
                                            
                                        <?php endif; ?>
                                        
                                    <?php endfor; ?>
                                    <?php if($processData[$key][0]['option_type']): ?>
                                        <a opt_type='ml_opt' id='option_<?php echo e($processData[$key][0]['question_id']); ?>' href='#' class='btn btn-primary btn-sm'>VOTE</a>
                                    <?php else: ?>
                                        <a opt_type='text_opt' data-target='textoption_<?php echo e($processData[$key][0]['question_id']); ?>' href='<?php echo e(URL::signedRoute('text_opt', 
                                            ['surveyId' => $processData[$key][0]['id'],
                                             'questionId'=>$processData[$key][0]['question_id'],
                                            ])); ?>' class='btn btn-primary btn-sm'>VOTE</a>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      
                      
                    </div>
                    <a class="carousel-control-prev" href="#detailedReports" id='prev_btn_slide' role="button" data-slide="prev">
                      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                      <span class="sr-only">Previous</span>
                    </a>
                    <a class="carousel-control-next" id='next_btn_slide' href="#detailedReports" role="button" data-slide="next">
                      <span class="carousel-control-next-icon" aria-hidden="true"></span>
                      <span class="sr-only">Next</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
    </div>        



<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script>
    addEventListener('click',(e)=>{
        if(e.target.type=='radio'){
            if(e.target.checked){
                document.getElementById(e.target.getAttribute('data-target')).setAttribute('href',e.target.getAttribute('url_ref'));
            }
            
        }

        

        if(e.target.getAttribute('opt_type')=='ml_opt'){
            e.preventDefault();
            if(e.target.getAttribute('href')=='#'){
               alert("Select your answer first");
            }else{
                

                $.get(e.target.getAttribute('href'), function(data, status){
                    e.target.remove();
                    document.getElementById('next_btn_slide').click()
                    //alert(JSON.parse(data)['msg'])
                });
                
            }
        }


        if(e.target.getAttribute('opt_type')=='text_opt'){
            e.preventDefault();
            // console.log(e.target.getAttribute('href'))
            // console.log(e.target.getAttribute('data-target'))
            // console.log(document.getElementById(e.target.getAttribute('data-target')).value);
            
            



            $.ajax({
            url: e.target.getAttribute('href'),
            type: "POST",
            
            data: {
                comment_text: document.getElementById(e.target.getAttribute('data-target')).value,
            },
            headers: {
                "X-CSRF-TOKEN": $('meta[name="csrf-token"]').attr("content"),
            },
            }).done(function (data) {
               
               e.target.remove();
               document.getElementById('next_btn_slide').click()
               //alert(JSON.parse(data)['msg'])
            });
        }
    })
</script><?php /**PATH C:\Users\webpers\Desktop\survay_project\surveyproject\resources\views/front.blade.php ENDPATH**/ ?>