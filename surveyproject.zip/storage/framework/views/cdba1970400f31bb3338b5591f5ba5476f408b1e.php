<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    table{
        border:1px solid black;
        width:100%;
    }
    table tr td,th{
        border:1px solid black;
    }
</style>
<body>
    <h3 style='text-align:center'><?php echo e($survey->survey_name); ?></h3>
    <table cellspacing='0'>
                      <thead>
                        <tr>
                          
                          <th>
                            Question name
                          </th>
                          <th>
                              Option list
                          </th>
                          
                          <th>
                              Total
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php
                            $questionId=0
                        ?>
                        <?php $__currentLoopData = $processData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <?php if($questionId!=$key): ?>
                                  <?php
                                      $questionId=$key
                                  ?>
                                  
                                    <td rowspan='<?php echo e(count($processData[$key])); ?>'><?php echo e($item->question_name); ?></td>
                                    <td><?php echo e($item->option_value); ?></td>
                                    <td><?php echo e($item->total); ?></td>
                                  
                              <?php else: ?>
                                  
                                    <td><?php echo e($item->option_value); ?></td>
                                    <td><?php echo e($item->total); ?></td>
                                  
                                  
                              <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $questionId=0;
                        ?>
                        <?php $__currentLoopData = $surveyTextOption; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                             <?php if($questionId != $text->question_id): ?>
                                <td rowspan="<?php echo e(getTotalAnswer($text->question_id,$text->id)); ?>">
                                 <?php echo e($text->question_name); ?>

                                </td>
                                <td colspan='2'>
                                    <?php echo e($text->option_value); ?>

                                </td>
                                <?php
                                    $questionId=$text->question_id;
                                ?>
                             <?php else: ?>
                                 
                                  <td colspan='2'>
                                      <?php echo e($text->option_value); ?>

                                  </td>
                             <?php endif; ?>
                             
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        
                        
                      </tbody>
                    </table>


<script>
    window.print();
</script>

                </body>

</html><?php /**PATH C:\Users\webpers\Desktop\survay_project\surveyproject\resources\views/survey_pdf.blade.php ENDPATH**/ ?>