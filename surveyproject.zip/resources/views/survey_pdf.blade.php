<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<style>
    table{
        border:1px solid black;
        width:100%;
    }
    table tr td,th{
        border:1px solid black;
    }
</style>
<body>
    <h3 style='text-align:center'>{{$survey->survey_name}}</h3>
    <table cellspacing='0'>
                      <thead>
                        <tr>
                          
                          <th>
                            Question name
                          </th>
                          <th>
                              Option list
                          </th>
                          
                          <th>
                              Total
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        @php
                            $questionId=0
                        @endphp
                        @foreach ($processData as $key=>$data)
                            @foreach ($data as $item)
                            <tr>
                              @if ($questionId!=$key)
                                  @php
                                      $questionId=$key
                                  @endphp
                                  
                                    <td rowspan='{{count($processData[$key])}}'>{{$item->question_name}}</td>
                                    <td>{{$item->option_value}}</td>
                                    <td>{{$item->total}}</td>
                                  
                              @else
                                  
                                    <td>{{$item->option_value}}</td>
                                    <td>{{$item->total}}</td>
                                  
                                  
                              @endif
                                </tr>
                            @endforeach
                            
                        @endforeach
                        @php
                            $questionId=0;
                        @endphp
                        @foreach ($surveyTextOption as $text)
                           <tr>
                             @if ($questionId != $text->question_id)
                                <td rowspan="{{getTotalAnswer($text->question_id,$text->id)}}">
                                 {{$text->question_name}}
                                </td>
                                <td colspan='2'>
                                    {{$text->option_value}}
                                </td>
                                @php
                                    $questionId=$text->question_id;
                                @endphp
                             @else
                                 
                                  <td colspan='2'>
                                      {{$text->option_value}}
                                  </td>
                             @endif
                             
                            </tr>
                        @endforeach  
                        
                        
                      </tbody>
                    </table>


<script>
    window.print();
</script>

                </body>

</html>